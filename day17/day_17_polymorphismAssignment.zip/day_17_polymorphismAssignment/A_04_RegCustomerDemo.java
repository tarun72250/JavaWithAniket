package day_11_polymorphismAssignment;

public class A_04_RegCustomerDemo {

	public static void main(String[] args) {

		A_04_RegCustomer r= new A_04_RegCustomer("tarunrathore2904@gmail.com","Bajrang Nagar","indore","462008",10002);
		r.display();
		System.out.println("-----------------------------");
		System.out.println(r);
	}

}
