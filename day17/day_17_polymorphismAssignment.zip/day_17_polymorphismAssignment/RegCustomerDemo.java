package day_11_polymorphismAssignment;

public class RegCustomerDemo {

	public static void main(String[] args) {

		RegCustomer r= new RegCustomer("tarunrathore2904@gmail.com","Bajrang Nagar","indore","462008",10002);
		r.display();
		System.out.println("-----------------------------");
		System.out.println(r);
	}

}
